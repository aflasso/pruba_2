class Semestre {
    constructor(numeroSemestre, cantCreditos, listadoClases) {
        this.numeroSemestre = numeroSemestre
        this.cantCreditos = cantCreditos
        this.listadoClases = listadoClases
    }
}

export default Semestre