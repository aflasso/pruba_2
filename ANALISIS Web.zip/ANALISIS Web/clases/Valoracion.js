class Valoracion{

    constructor(asunto, comentario, puntuacion) {
        
        this.asunto = asunto
        this.comentario = comentario
        this.puntuacion = puntuacion
    }

}

export default Valoracion