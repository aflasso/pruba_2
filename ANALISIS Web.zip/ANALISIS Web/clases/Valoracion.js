class Valoracion{

}

export default Valoracion