import baseDatos from "../perfilesbd/baseDatos.js";

console.log(baseDatos)